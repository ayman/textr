return {
   title  = LOC "$$$/shamurai/textr/pluginName=Textr OCR",
   id = 'TextrTagset',
   items = {
      'com.shamurai.textr.*',
      'com.adobe.separator',         
      'com.adobe.title',
      { 'com.adobe.caption', height_in_lines = 3 },
      'com.adobe.separator',
      'com.adobe.dateCreated',
      'com.adobe.filename',
      'com.adobe.folder',
   }
}
