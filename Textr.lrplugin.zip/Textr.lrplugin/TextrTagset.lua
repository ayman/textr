return {
   label  =  LOC  "$$$/Textr/Tagset/Title=Textr",
   id = 'TextrTagset',
   items = {
      { 'com.adobe.label',
        label  =  LOC  "$$$/Metadata/OrigLabel=Standard Metadata"},
      'com.adobe.filename',
      'com.adobe.folder',
      'com.adobe.separator',
      { 'com.adobe.label', label = LOC "$$$/Metadata/CusLabel=Textr" },
      'com.shamurai.textr.*',
   },
}
