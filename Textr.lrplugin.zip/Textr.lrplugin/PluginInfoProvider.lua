require 'PluginManager'

return {
   sectionsForTopOfDialog = PluginManager.sectionsForTopOfDialog,
}
