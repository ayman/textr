require 'PluginManager'

return {
   sectionsForTopOfDialog = PluginManager.sectionsForTopOfDialog,
   sectionsForBottomOfDialog = PluginManager.sectionsForBottomOfDialog,
}
