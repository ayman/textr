return {
   schemaVersion = 6,
   metadataFieldsForPhotos = {
      {
         id = 'textrFoundText',
         title = LOC "$$$/shamurai/textr/foundtext=Found Text",
         dataType = 'string',
         browsable = true,
         searchable = true,
         version = 5
      },
   },
}
