return {
   schemaVersion = 6,
   metadataFieldsForPhotos = {
      {
         id = 'textrFoundText',
         title = _G.FOUND_TEXT,
         dataType = 'string',
         browsable = true,
         searchable = true,
         version = 5
      },
   },
}
