_G.pluginID = "com.shamurai.textr"
_G.URL = "https://console.cloud.google.com"
