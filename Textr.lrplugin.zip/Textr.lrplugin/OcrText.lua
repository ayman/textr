-- local LR = import 'LR'

local LrApplication = import 'LrApplication'   -- Import LR namespace which provides access to active catalog
local LrDialogs = import 'LrDialogs'   -- Import LR namespace for user dialog functions
local LrTasks = import 'LrTasks'       -- Import functions for starting async tasks
local LrHttp = import 'LrHttp'
local LrStringUtils = import 'LrStringUtils'
local LrView = import 'LrView'
local LrPrefs = import 'LrPrefs'

local JSON = require 'JSON'

-- local log = Lr.Logger()
-- log:enable('print')
-- log:info("Loading module...")

local ENDPOINT_URL = "https://vision.googleapis.com/v1/images:annotate"
local API_KEY = LrPrefs.prefsForPlugin().google_api_key

LrTasks.startAsyncTask (
   function()          
      -- Make this coroutine known to ZBS
      --  LrMobdebug.on()                           
      -- Get the active LR catalog.
      catalog = LrApplication.activeCatalog()   
      -- Get the photo currently selected by the user. (type: LrPhoto)
      selectedPhoto = catalog:getTargetPhoto()  
      -- https://forums.adobe.com/message/3948416#3948416

      local holdRefObj = 1
      holdRefObj = selectedPhoto:requestJpegThumbnail(
         320,
         nil,
         function(dat, err)
            if dat == nil then
               LrDialogs.message("nil data")
            else
               local b64 = LrStringUtils.encodeBase64(dat)
               local response = callPOST(ENDPOINT_URL, b64)
               local ocr = JSON:decode(response)
               local annotations = ocr.responses[1].textAnnotations
               if annotations == nil then
                  -- no text found
                  return
               end                     
               local tagsText = ""
               for i, text in ipairs(annotations) do
                  tagsText = tagsText .. text.description .. " "
               end
               LrDialogs.message(tagsText)
            end
         end
      )      
   end
)

-- Helper function to round value <num> to <idp> decimal places
function round(num, idp)                
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

function trim(s)
  return (s:gsub("^%s*(.-)%s*$", "%1"))
end

function FastBytesToString(bytes)
  s = {}
  for i = 1, getn(bytes) do
    s[i] = strchar(bytes[i])
  end
  return concat(s)
end

function makeImageData( data )
   d = "{requests:[{image:{content: \""
      .. data
      .. "\"}, features: [{type:'TEXT_DETECTION', maxResults: 1}]}]}"
   return d
end     

function callPOST( url, data )
   return LrHttp.post(
      url .. "?key=" .. API_KEY,
      -- query_string,
      makeImageData(data),
      { -- auth_header,
         { field = "Content-Type", value = "application/json" },
         { field = "User-Agent", value = "Textr Plugin 1.0" },
         { field = "Cookie", value = "GARBAGE" } }
   )
end


function call_it( method, url )
   if method == "POST" then
      return LrHttp.post(
         url,
         -- query_string,
         "api=" .. "AIzaSyC3rsqE2XLfD5tkFbWMpVL0DTBWIpOmbeA",
         { -- auth_header,
            { field = "Content-Type", value = "application/json" },
            { field = "User-Agent", value = "Textr Plugin 1.0" },
            { field = "Cookie", value = "GARBAGE" } }
      )
   else
      return LrHttp.get( url )
   end
end


-- -- https://gist.github.com/bortels/1436940
-- -- Lua 5.1+ base64 v3.0 (c) 2009 by Alex Kloss <alexthkloss@web.de>
-- -- licensed under the terms of the LGPL2

-- -- character table string
-- local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

-- -- encoding
-- function enc(data)
--    return ((data:gsub('.',
--                       function(x) 
--                          local r,b='',x:byte()
--                          for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end
--                          return r;
--                      end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
--                                            if (#x < 6) then return '' end
--                                            local c=0
--                                            for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end
--                                            return b:sub(c+1,c+1)
--                                        end)..({ '', '==', '=' })[#data%3+1])
-- end

-- -- decoding
-- function dec(data)
--    data = string.gsub(data, '[^'..b..'=]', '')
--    return (data:gsub('.',
--                      function(x)
--                         if (x == '=') then return '' end
--                         local r,f='',(b:find(x)-1)
--                         for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
--                         return r;
--                     end):gsub('%d%d%d?%d?%d?%d?%d?%d?',
--                               function(x)
--                                  if (#x ~= 8) then return '' end
--                                  local c=0
--                                  for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(7-i) or 0) end
--                                  return string.char(c)
--    end))
-- end
